require("model2");	-- Import model2 machine globals

function Init()
	
end

function Frame()
	  Model2_SetWideScreen(0)

	 Model2_SetStretchALow(0)
	Model2_SetStretchAHigh(0)

	 Model2_SetStretchBLow(0)
	Model2_SetStretchBHigh(0)
end