User guide is now online:
https://github.com/argonlefou/DemulShooter/wiki