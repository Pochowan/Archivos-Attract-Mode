require("model2");	-- Import model2 machine globals

function Init()
	
end

function Frame()
	  Model2_SetWideScreen(1)

	 Model2_SetStretchALow(1)
	Model2_SetStretchAHigh(1)

	 Model2_SetStretchBLow(1)
	Model2_SetStretchBHigh(1)
end